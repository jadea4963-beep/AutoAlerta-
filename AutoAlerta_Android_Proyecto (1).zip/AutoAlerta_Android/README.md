# AutoAlerta Android (proyecto inicial)

Este proyecto implementa Bluetooth clásico SPP para un módulo HC-05 ya vinculado con el teléfono.

## Funciones incluidas
- Lista los dispositivos Bluetooth previamente vinculados.
- Conecta al dispositivo seleccionado mediante SPP.
- Envía el carácter ASCII `1` al tocar ENCENDER.
- Envía el carácter ASCII `0` al tocar APAGAR BOMBA.
- Escucha mensajes terminados en salto de línea. Si recibe `ALERTA`, muestra aviso y reproduce un tono.
- Abre el marcador telefónico con 911 (no realiza la llamada automáticamente).

## Antes de probar
1. En Android, vincula el módulo HC-05 desde Ajustes > Bluetooth.
2. Abre el proyecto en Android Studio (JDK 17 y Android SDK 35).
3. Ejecuta la app en un teléfono Android con Bluetooth clásico.
4. Concede el permiso Bluetooth cuando Android lo solicite.
5. En la app, toca CONECTAR HC-05 y selecciona el módulo vinculado.

## Importante sobre el Arduino
El sketch compartido recibe `1` y `0`, pero todavía no envía `ALERTA`. La recepción de alertas en la app solo podrá probarse cuando se identifique e integre un sensor y Arduino envíe, por ejemplo, `BT.println("ALERTA");`.

El HTML anterior no puede comunicarse directamente con el HC-05 clásico desde un navegador Android común; por eso se necesita esta app nativa.

## Pruebas seguras
Prueba primero en una mesa con una carga de baja tensión o un LED/indicador adecuado. No conectes este prototipo al sistema de combustible ni a un vehículo en movimiento. Verifica el circuito con una persona capacitada antes de energizarlo.
