package com.autoalerta.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val sppUuid: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var readerThread: Thread? = null
    private var tone: ToneGenerator? = null

    private lateinit var connectionText: TextView
    private lateinit var pumpText: TextView
    private lateinit var alertText: TextView
    private lateinit var connectButton: Button
    private lateinit var silenceButton: Button

    private val navy = Color.rgb(8, 19, 33)
    private val panel = Color.rgb(16, 34, 56)
    private val line = Color.rgb(36, 65, 93)
    private val white = Color.rgb(237, 245, 255)
    private val muted = Color.rgb(157, 178, 200)
    private val green = Color.rgb(72, 214, 160)
    private val red = Color.rgb(255, 83, 104)
    private val gold = Color.rgb(255, 196, 94)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        buildScreen()
        ensureBluetoothPermission()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "AUTOALERTA"
            textSize = 26f
            setTextColor(white)
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(brand)
        root.addView(text("SISTEMA ANTIRROBO · PANEL DE CONTROL", muted, 12f).also {
            it.setPadding(0, dp(4), 0, dp(20))
        })

        val statusCard = card()
        connectionText = text("Sin conexión Bluetooth", white, 17f, true)
        statusCard.addView(connectionText)
        statusCard.addView(text("Conecta el módulo HC-05 previamente vinculado en Android.", muted, 13f))
        root.addView(statusCard)

        val controlCard = card()
        controlCard.addView(sectionLabel("CONTROL DE BOMBA"))
        connectButton = button("CONECTAR HC-05", Color.rgb(37, 75, 108), white) {
            showPairedDevices()
        }
        controlCard.addView(connectButton)
        controlCard.addView(button("ENCENDER · ENVIAR 1", green, navy) {
            sendCommand('1', "Solicitud de encendido enviada. Confirma el circuito de prueba.")
        })
        controlCard.addView(button("APAGAR BOMBA · ENVIAR 0", red, Color.WHITE) {
            sendCommand('0', "Solicitud de apagado enviada. Confirma el circuito de prueba.")
        })
        pumpText = text("Estado de salida: sin confirmar", muted, 13f)
        controlCard.addView(pumpText)
        root.addView(controlCard)

        val alertCard = card()
        alertCard.addView(sectionLabel("DETECCIÓN Y ALERTAS"))
        alertText = text("No se ha recibido ninguna alerta.", white, 15f)
        alertCard.addView(alertText)
        silenceButton = button("SILENCIAR SONIDO", Color.rgb(27, 56, 83), white) {
            stopAlarm()
            alertText.text = "Sonido silenciado."
        }
        alertCard.addView(silenceButton)
        alertCard.addView(text(
            "La alerta automática quedará pendiente hasta identificar e integrar el sensor. " +
                "Cuando Arduino envíe el texto ALERTA, la app reproducirá un aviso.",
            muted, 13f
        ))
        root.addView(alertCard)

        val emergencyCard = card()
        emergencyCard.addView(sectionLabel("EMERGENCIAS"))
        emergencyCard.addView(button("ABRIR MARCADOR · 911", gold, navy) {
            startActivity(Intent(Intent.ACTION_DIAL).setData(android.net.Uri.parse("tel:911")))
        })
        emergencyCard.addView(text(
            "Abre el marcador para que puedas revisar y confirmar la llamada.",
            muted, 13f
        ))
        root.addView(emergencyCard)

        root.addView(text(
            "Prototipo escolar. Prueba primero con una carga de baja tensión/indicador, " +
                "no conectado al sistema de combustible ni a un vehículo en movimiento.",
            muted, 12f
        ).apply { setPadding(dp(4), dp(14), dp(4), 0) })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(panel, dp(18), line)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(14)
        layoutParams = params
    }

    private fun sectionLabel(value: String) = text(value, muted, 12f, true).apply {
        setPadding(0, 0, 0, dp(8))
    }

    private fun text(
        value: String, color: Int, size: Float, bold: Boolean = false
    ) = TextView(this).apply {
        text = value
        setTextColor(color)
        textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun button(
        label: String, color: Int, textColor: Int, action: () -> Unit
    ) = Button(this).apply {
        text = label
        setTextColor(textColor)
        textSize = 14f
        setTypeface(null, Typeface.BOLD)
        background = rounded(color, dp(12))
        isAllCaps = false
        setPadding(dp(8), dp(8), dp(8), dp(8))
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.topMargin = dp(8)
        layoutParams = params
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun ensureBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 41)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
            connectionText.text = "Permiso Bluetooth denegado. Actívalo en Ajustes."
        }
    }

    private fun showPairedDevices() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            ensureBluetoothPermission()
            return
        }
        val adapter = bluetoothAdapter
        if (adapter == null) {
            connectionText.text = "Este teléfono no admite Bluetooth."
            return
        }
        if (!adapter.isEnabled) {
            connectionText.text = "Activa Bluetooth en los ajustes del teléfono."
            startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }
        val devices = try { adapter.bondedDevices?.toList().orEmpty() }
        catch (_: SecurityException) { emptyList() }

        if (devices.isEmpty()) {
            connectionText.text = "Primero vincula el HC-05 desde Ajustes > Bluetooth."
            startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }

        val labels = devices.map { "${it.name ?: "Dispositivo"}  ·  ${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Selecciona tu HC-05")
            .setItems(labels) { _, which -> connectTo(devices[which]) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun connectTo(device: BluetoothDevice) {
        connectionText.text = "Conectando con ${device.name ?: "HC-05"}..."
        thread {
            try {
                try { bluetoothAdapter?.cancelDiscovery() } catch (_: SecurityException) {}
                val newSocket = device.createRfcommSocketToServiceRecord(sppUuid)
                newSocket.connect()
                socket?.close()
                socket = newSocket
                runOnUiThread {
                    connectionText.text = "Conectado a ${device.name ?: "HC-05"}"
                    pumpText.text = "Bluetooth conectado. Estado de salida sin confirmar."
                    connectButton.text = "CAMBIAR DISPOSITIVO"
                }
                listenForMessages(newSocket)
            } catch (e: Exception) {
                runOnUiThread {
                    connectionText.text = "No se pudo conectar. Verifica el HC-05 y vuelve a intentar."
                }
            }
        }
    }

    private fun sendCommand(command: Char, description: String) {
        val activeSocket = socket
        if (activeSocket == null || !activeSocket.isConnected) {
            pumpText.text = "Sin conexión: conecta primero el HC-05."
            return
        }
        thread {
            try {
                activeSocket.outputStream.write(command.code)
                activeSocket.outputStream.flush()
                runOnUiThread { pumpText.text = description }
            } catch (_: IOException) {
                runOnUiThread {
                    pumpText.text = "No se pudo enviar el comando. Revisa la conexión."
                    connectionText.text = "Conexión interrumpida"
                }
                closeSocket()
            }
        }
    }

    private fun listenForMessages(activeSocket: BluetoothSocket) {
        readerThread = thread {
            val buffer = ByteArray(128)
            val pending = StringBuilder()
            try {
                while (activeSocket.isConnected) {
                    val count = activeSocket.inputStream.read(buffer)
                    if (count < 0) break
                    pending.append(String(buffer, 0, count, Charsets.UTF_8))
                    while (pending.contains("\n") || pending.contains("\r")) {
                        val lineEnd = (0 until pending.length).firstOrNull {
                            pending[it] == '\n' || pending[it] == '\r'
                        } ?: break
                        val message = pending.substring(0, lineEnd).trim()
                        pending.delete(0, lineEnd + 1)
                        if (message.equals("ALERTA", ignoreCase = true)) {
                            runOnUiThread {
                                alertText.text = "⚠ ALERTA RECIBIDA DESDE ARDUINO"
                                startAlarm()
                            }
                        }
                    }
                }
            } catch (_: IOException) {
                // La conexión se cerró.
            } finally {
                runOnUiThread {
                    if (socket === activeSocket) connectionText.text = "Sin conexión Bluetooth"
                }
            }
        }
    }

    private fun startAlarm() {
        try {
            stopAlarm()
            tone = ToneGenerator(AudioManager.STREAM_ALARM, 85).also {
                it.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500)
            }
        } catch (_: Exception) {
            alertText.text = "Alerta recibida. El teléfono no pudo reproducir el sonido."
        }
    }

    private fun stopAlarm() {
        try { tone?.stopTone(); tone?.release() } catch (_: Exception) {}
        tone = null
    }

    private fun closeSocket() {
        try { socket?.close() } catch (_: IOException) {}
        socket = null
    }

    override fun onDestroy() {
        stopAlarm()
        closeSocket()
        super.onDestroy()
    }
}
